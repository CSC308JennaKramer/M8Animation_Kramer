import UIKit

let arr = [1,2,3,4,5,6,7,8,9,10]
let result = arr.filter({(num: Int) -> Bool in
    return num.isMultiple(of: 2)
})
print(result)

let result2 = arr.filter({
    return $0.isMultiple(of: 2)
})
print(result2)

let result3 = arr.filter({ $0.isMultiple(of: 2)}) //implicit return, inline closure
print(result3)

let result4 = arr.filter{ $0.isMultiple(of: 2)} //trailing
print(result4)

//Tasl 1
let cast = ["Vivien", "Marlon", "Kim", "Karl"]
var taskResult = cast.filter({(name: String) -> Bool in
    return name.count < 5
})
print(taskResult)

taskResult = cast.filter({(name) in
    return name.count < 5
})
print(taskResult)

taskResult = cast.filter({
    return $0.count < 5
})
print(taskResult)


taskResult = cast.filter({ $0.count < 5})
print(taskResult)

taskResult = cast.filter{ $0.count < 5}
print(taskResult)

//Task 2
var a = cast.contains(where: {(name: String) -> Bool in
    return name.hasPrefix("V")
})
print(a)

a = cast.contains(where: {
    return $0.hasPrefix("V")
})
print(a)
a = cast.contains(where: { $0.hasPrefix("V")
})

print(a)

a = cast.contains{ $0.hasPrefix("V")}
print(a)

a = cast.contains(where: {
    return $0.hasPrefix("V")
})
print(a)

a = cast.contains{
    return $0.hasPrefix("V")
}
print(a)
